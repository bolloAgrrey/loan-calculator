
<?php
	
	echo "<div>"
	echo "<h6>connection to php made via ajax"</h6>;
	echo "Amount taken: " ;
	echo $_GET['amount_taken'];
?>